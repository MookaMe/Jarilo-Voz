# Jarilo — Teaser V3 revisado

A revisão preserva a surpresa: **“Prepare-se. Um novo Jarilo vai te encontrar.”**
A explicação da novidade foi retirada das peças e das legendas sugeridas.
As versões V1 e V2 continuam preservadas como estudos anteriores.

## Abrir e comparar

- `index.html`: galeria com imagens de feed/story e vídeos, sem iframes.
- `Jarilo-V3-teaser.html`: apresentação em arquivo único, com fontes, imagens,
  vídeos e PDF incluídos para exibição sem arquivos auxiliares.
- `briefing.md`: análise, decisões atualizadas e sugestões de legendas.

A galeria anterior incorporava páginas HTML em iframes, bloqueados no visualizador
mostrado pelo usuário. A apresentação corrigida usa PNGs para essa visualização;
os HTMLs editáveis de cada peça continuam disponíveis no pacote.

## Entregas

| Formato | Clara | Escura | Exports |
| --- | --- | --- | --- |
| Feed 1080 × 1350 | `feed-claro.html` | `feed-escuro.html` | PNG e PDF |
| Story 1080 × 1920 | `story-claro.html` | `story-escuro.html` | Mockup PNG/PDF e PNG base |
| Reels 1080 × 1920 | `reels-claro.html` | `reels-escuro.html` | MP4 de 8 s, 30 fps, H.264/yuv420p; HTML animado; 3 quadros PNG/PDF |

Em `exports`, `jarilo-v3-teaser.pdf` reúne dez páginas: feed, story e três cenas
por tema. O PDF é estático; as animações reais são `reels-claro.mp4` e
`reels-escuro.mp4`. `jarilo-v3-teaser-visao-geral.png` permite comparar os seis
criativos. O pacote `Jarilo-V3-Revisado.zip` reúne fontes e exportações, com um
`index.html` pronto para abrir na pasta inicial, após extrair o ZIP.

## Story

Pergunta: **O que você acha que vem aí?**
Opções: **Tenho um palpite** / **Me surpreenda**.

A enquete no mockup é ilustrativa. Para publicar, usar `story-{tema}-base.png`
e inserir o sticker nativo na área reservada: aproximadamente x172/y1281,
736 × 128 px, ajustando ao formato disponível na plataforma. O texto essencial
fica abaixo de y250 e acima de y1650 na arte 1080 × 1920.

## Motion e sinais visuais

1. 00–02 s: O campo tem muito a dizer.
2. 02–05,6 s: Prepare-se. Um novo Jarilo vai te encontrar.
3. 05,6–08 s: Prepare-se. Em breve.

A onda é uma pista gráfica livre, sem player, microfone, estado ativo ou tutorial.
Os vídeos estão sem áudio. Os controles do HTML ficam fora da arte; a preferência
por movimento reduzido mantém a prévia estática.

## Editar e reproduzir

`art.css` define as peças; `motion.js` define a animação; `gallery.*` define a
apresentação. As fontes e a imagem original da assinatura ficam em `../assets`.
Barlow e Barlow Condensed são escolhas para o mockup, sem confirmação da fonte
oficial. Confirmar tokens e logo separado em SVG/PNG transparente na produção.

Na raiz `jarilo-voz`, com Python, Chromium, Playwright, FFmpeg e PyMuPDF disponíveis:

```sh
python3 scripts/build_v3.py
node scripts/export_static_v3.mjs
node scripts/export_motion_v3.mjs
python3 scripts/finalize_v3.py
python3 scripts/build_portable_v3.py
node scripts/review_v3.mjs
python3 scripts/package_v3.py
```

O empacotador salva a entrega em `entrega/Jarilo-V3-Revisado.zip`, a partir da
raiz do projeto, e verifica os arquivos após extraí-los em uma pasta temporária.

Os servidores de verificação são temporários. Os MP4s são verificados com ffprobe.
A galeria é conferida com páginas incorporadas bloqueadas (`frame-src 'none'`),
e o HTML único com requests de assets externos bloqueados. Esses testes são
locais; não afirmam execução dentro do visualizador do usuário.

Nada foi publicado, agendado ou enviado.
