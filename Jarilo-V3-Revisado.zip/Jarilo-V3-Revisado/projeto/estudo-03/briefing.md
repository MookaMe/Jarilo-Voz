# Jarilo — V3 revisada: expectativa antes da revelação

## Direção que prevalece

A orientação mais recente do usuário é preservar a surpresa do lançamento.
A mensagem deve ficar nas entrelinhas: gerar curiosidade, sem dizer o que a
funcionalidade faz ou convidar a experimentá-la.

O PDF de planejamento, páginas 10 e 12, já distingue o pré-lançamento da revelação:
**“Prepare-se: um novo Jarilo vai te encontrar.”** é a referência desta revisão.
A frase explícita prevista na user story anterior foi retirada de feed, story,
Reels, textos alternativos, capas, legendas e metadados públicos.

## Decisões de alinhamento

| Ponto | Decisão |
| --- | --- |
| Período | 28/10 a 02/11, conforme user story mais recente sobre o período; o PDF começa em 29/10. |
| Mensagem | Expectativa, sem nomear o recurso ou explicar seu funcionamento. |
| Aparência | Clara e escura, com castanho, creme e pequenos acentos verdes. |
| Pista visual | Sinal abstrato em movimento e curvas de terreno. Retirados o player literal, o halo de estado ativo, microfone e controles. |
| Story | A pergunta anterior apontava demais para a solução. Foi substituída por uma enquete de curiosidade, seguindo a correção atual do usuário. |
| Mídia | Conteúdo orgânico, sem compra de mídia, envio ou publicação. |

## Feed · 1080 × 1350

**Mensagem:** “Prepare-se. Um novo Jarilo vai te encontrar.”

**Assinatura:** “Em breve.” / “Fique de olho.”

**Legenda sugerida:**

> Tem novidade no campo. 🌱
>
> Prepare-se: um novo Jarilo vai te encontrar.
>
> Por enquanto, fica a pista. Em breve, a gente conta mais.

A arte não mostra interface, funções, instruções de uso ou uma data de liberação.

## Story · 1080 × 1920

**Pergunta:** “O que você acha que vem aí?”

**Opções:** “Tenho um palpite” / “Me surpreenda”.

**Apoio:** “Tem novidade chegando no Jarilo.”

A enquete ilustrada não coleta votos. Na publicação, usar o PNG base e inserir o
sticker nativo da plataforma. A pergunta e as duas opções devem permanecer abertas
à imaginação, sem sugerir uma função específica.

## Reels · 1080 × 1920 · 8 segundos

| Tempo | Texto | Papel |
| --- | --- | --- |
| 00–02 s | O campo tem muito a dizer. | Criar conexão e apresentar uma pista. |
| 02–05,6 s | Prepare-se. Um novo Jarilo vai te encontrar. | Aumentar a expectativa sem explicar a novidade. |
| 05,6–08 s | Prepare-se. Em breve. | Encerrar com curiosidade e marca reconhecível. |

O sinal abstrato ganha movimento; não há uma demonstração de produto. O vídeo é
compreensível sem som e não usa uma locução provisória que possa antecipar o recurso.

**Legenda sugerida:**

> O campo tem muito a dizer. E tem novidade chegando por aqui. 🌱
>
> Um novo Jarilo vai te encontrar. O que será que vem aí?

## Apresentação e arquivos

A galeria deixou de usar iframes para as peças de feed e story. Esses elementos
foram substituídos pelos PNGs, porque o visualizador do usuário bloqueou as páginas
incorporadas. Há também uma apresentação em arquivo único, com imagens, fontes,
vídeos e PDF incluídos, além dos HTMLs editáveis de cada peça.

O PDF mostra as artes e o storyboard; o movimento está nos MP4s. Os dois temas
mantêm a mesma mensagem. Nenhuma peça foi enviada ou publicada.

## Pendências de produção e medição

- Confirmar disponibilidade antes de mudar de expectativa para revelação.
- O encerramento da campanha do podcast até 28/10 continua sendo uma suposição.
- Confirmar tipografia e tokens oficiais; a assinatura utiliza a arte original
  fornecida, sem recriar o personagem de capturas de baixa resolução.
- As metas de cinco ações e de engajamento acima da média dos últimos cinco Reels
  pertencem à campanha publicada. A entrega de criativos não comprova esses resultados.
- Uma eventual peça de revelação terá briefing próprio; estes arquivos permanecem
  restritos ao teaser de pré-lançamento.
