/* Play only visible previews; respect reduced motion and any explicit pause. */
const videos = [...document.querySelectorAll('video')];
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
const manuallyPaused = new WeakSet();
const internallyPaused = new WeakSet();

function pausePreview(video) {
  if (video.paused) return;
  internallyPaused.add(video);
  video.pause();
}

for (const video of videos) {
  video.muted = true;
  if (reducedMotion.matches) {
    video.autoplay = false;
    pausePreview(video);
  }
  video.addEventListener('pause', () => {
    if (internallyPaused.has(video)) internallyPaused.delete(video);
    else manuallyPaused.add(video);
  });
  video.addEventListener('play', () => manuallyPaused.delete(video));
}

if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    for (const entry of entries) {
      const video = entry.target;
      if (!entry.isIntersecting || reducedMotion.matches || document.hidden) {
        pausePreview(video);
      } else if (!manuallyPaused.has(video)) {
        video.play().catch(() => {});
      }
    }
  }, { threshold: 0.2 });
  videos.forEach(video => observer.observe(video));
}

document.addEventListener('visibilitychange', () => {
  if (document.hidden) videos.forEach(pausePreview);
});

reducedMotion.addEventListener?.('change', event => {
  if (event.matches) videos.forEach(pausePreview);
});
