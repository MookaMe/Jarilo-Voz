/* Jarilo V3 · deterministic eight-second motion. All visuals remain HTML/SVG. */
(() => {
  'use strict';
  const DURATION = 8;
  const clamp = (value, min = 0, max = 1) => Math.min(max, Math.max(min, value));
  const smooth = (from, to, time) => {
    const value = clamp((time - from) / (to - from));
    return value * value * (3 - 2 * value);
  };

  function initialize() {
    const art = document.querySelector('.art');
    if (!art) return;
    const scenes = Object.fromEntries(
      [...document.querySelectorAll('.motion-scene[data-scene]')].map(element => [element.dataset.scene, element])
    );
    const bars = [...document.querySelectorAll('.wave-bar')].map((element, index) => ({
      element,
      index,
      base: Number(element.dataset.baseHeight || element.getAttribute('height') || 20)
    }));
    const orbs = [...document.querySelectorAll('.voice-orb')];
    const capsule = document.querySelector('.motion-capsule');
    const playControls = [...document.querySelectorAll('[data-action="play"]')];
    const seekControls = [...document.querySelectorAll('input[data-action="seek"]')];
    const timeControls = [...document.querySelectorAll('[data-time]')];
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    const exporting = new URLSearchParams(location.search).get('export') === '1';
    const loops = art.dataset.loop !== 'false';
    let time = 0;
    let running = false;
    let frame = null;
    let startedAt = 0;

    function scene(name, opacity, y) {
      const element = scenes[name];
      if (!element) return;
      element.style.opacity = String(opacity);
      element.style.visibility = opacity < .001 ? 'hidden' : 'visible';
      element.style.transform = `translate3d(0, ${y.toFixed(3)}px, 0)`;
      element.setAttribute('aria-hidden', opacity < .5 ? 'true' : 'false');
      element.style.pointerEvents = 'none';
    }

    function render() {
      const firstTransition = smooth(1.72, 2.12, time);
      const secondTransition = smooth(5.42, 5.82, time);
      scene('intro', 1 - firstTransition, 18 * (1 - smooth(0, .55, time)) - 14 * firstTransition);
      scene('reveal', firstTransition * (1 - secondTransition), 24 * (1 - smooth(1.72, 2.25, time)) - 16 * secondTransition);
      scene('outro', secondTransition, 22 * (1 - smooth(5.42, 5.98, time)));

      for (const { element, index, base } of bars) {
        const speech = .43 + .57 * (.5 + .5 * Math.sin(time * 5.1 + index * .57 + Math.sin(time * 2.7 + index * .19)));
        const breath = .84 + .16 * Math.sin(time * 2.05 + .6);
        const height = Math.max(4, base * speech * breath);
        element.setAttribute('height', height.toFixed(3));
        element.setAttribute('y', (90 - height / 2).toFixed(3));
      }
      for (const orb of orbs) {
        const pulse = .985 + .045 * (.5 + .5 * Math.sin(time * 4.2));
        orb.style.transform = `scale(${pulse.toFixed(4)})`;
        orb.style.opacity = String(.88 + .12 * (.5 + .5 * Math.sin(time * 3.1)));
      }
      if (capsule) {
        capsule.style.transform = `translate3d(0, ${(-2.8 * Math.sin(time * 1.8)).toFixed(3)}px, 0)`;
      }
      art.dataset.motionTime = time.toFixed(3);
      for (const control of seekControls) {
        if (document.activeElement !== control) control.value = String(time);
      }
      for (const control of timeControls) control.textContent = `${time.toFixed(1).replace('.', ',')} s / 8 s`;
      for (const control of playControls) {
        control.textContent = running ? 'Pausar' : 'Reproduzir';
        control.setAttribute('aria-label', running ? 'Pausar animação' : 'Reproduzir animação');
        control.setAttribute('aria-pressed', String(running));
      }
    }

    function tick(now) {
      if (!running) return;
      const elapsed = Math.max(0, (now - startedAt) / 1000);
      if (elapsed >= DURATION && !loops) {
        time = DURATION;
        pause();
        return;
      }
      time = loops ? elapsed % DURATION : Math.min(DURATION, elapsed);
      render();
      frame = requestAnimationFrame(tick);
    }

    function pause() {
      running = false;
      if (frame !== null) cancelAnimationFrame(frame);
      frame = null;
      render();
    }

    function seek(value) {
      const numeric = Number(value);
      time = Number.isFinite(numeric) ? clamp(numeric, 0, DURATION) : 0;
      if (running) startedAt = performance.now() - time * 1000;
      render();
      return time;
    }

    function play() {
      if (running) return;
      if (time >= DURATION) time = 0;
      running = true;
      startedAt = performance.now() - time * 1000;
      render();
      frame = requestAnimationFrame(tick);
    }

    for (const control of playControls) control.addEventListener('click', () => running ? pause() : play());
    for (const control of document.querySelectorAll('[data-action="restart"]')) {
      control.addEventListener('click', () => { seek(0); play(); });
    }
    for (const control of seekControls) {
      control.min = '0';
      control.max = String(DURATION);
      control.step = '.01';
      control.addEventListener('input', () => {
        const position = control.value;
        pause();
        seek(position);
      });
    }

    window.jariloMotion = Object.freeze({
      duration: DURATION,
      seek,
      play,
      pause,
      get currentTime() { return time; },
      get running() { return running; }
    });
    render();
    if (exporting) {
      seek(0);
    } else if (reduced.matches) {
      seek(3.8);
    } else {
      play();
    }
    reduced.addEventListener('change', event => {
      if (event.matches) { pause(); seek(3.8); }
    });
    document.dispatchEvent(new CustomEvent('jarilo-motion-ready'));
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize, { once: true });
  else initialize();
})();
