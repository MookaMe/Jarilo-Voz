"""Assemble the ten-page creative/storyboard PDF with bookmarks and checks."""
from pathlib import Path
from shutil import copyfile
import fitz

root=Path(__file__).resolve().parent.parent/'estudo-03'
out=root/'exports'
book=fitz.open()
toc=[]
for theme,label in [('claro','Clara'),('escuro','Escura')]:
    toc.append([1,f'Versão {label}',len(book)+1])
    pieces=[('feed','Feed',1350,['PREPARE-SE','UMNOVO','JARILO','VAITEENCONTRAR']),
            ('story','Story — enquete',1920,['OQUEVOCÊ','ACHAQUE','VEMAÍ','TENHOUMPALPITE','MESURPREENDA']),
            ('reels-cena-1','Reels — 00 a 02 s',1920,['OCAMPOTEM','ADIZER']),
            ('reels-cena-2','Reels — 02 a 05,6 s',1920,['PREPARE-SE','UMNOVO','JARILO','VAITEENCONTRAR']),
            ('reels-cena-3','Reels — 05,6 a 08 s',1920,['PREPARE-SE','EMBREVE'])]
    for key,title,height,expected in pieces:
        filename=f'{key}-{theme}.pdf' if not key.startswith('reels') else f'reels-{theme}-cena-{key[-1]}.pdf'
        with fitz.open(out/filename) as src:
            assert len(src)==1,filename
            page=src[0]
            assert abs(page.rect.width-810)<1 and abs(page.rect.height-height*.75)<1,(filename,page.rect)
            text=''.join(page.get_text().split()).upper()
            assert all(word in text for word in expected),(filename,text)
            assert not any(word in text for word in ['VOZ','DIGITAR','OUFALAR','CONVERSAR']), (filename,text)
            book.insert_pdf(src)
            toc.append([2,title,len(book)])
book.set_toc(toc)
book.set_metadata({'title':'Jarilo — Teaser V3 — Clara e escura',
                   'author':'Jarilo',
                   'subject':'Pré-lançamento: Feed, Story e storyboard do Reels de 8 segundos. O movimento está nos arquivos MP4.'})
target=out/'jarilo-v3-teaser.pdf'
book.save(target,garbage=4,deflate=True)
copyfile(target,out/'jarilo-v3-apresentacao.pdf')
with fitz.open(target) as check:
    assert len(check)==10
    assert len(check.get_toc())==12
print('PDF verificado: 10 páginas, dois temas, feed + story + 3 cenas do Reels por tema.')
