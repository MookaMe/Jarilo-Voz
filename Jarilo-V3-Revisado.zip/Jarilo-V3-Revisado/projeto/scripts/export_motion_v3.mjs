/** Export the actual HTML motion at exact frame times; no screen recording jitter. */
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { createServer } from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { once } from 'node:events';
import { spawn, execFileSync } from 'node:child_process';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const exportsRoot = path.join(root, 'estudo-03', 'exports');
const fps = 30;
const duration = 8;
const frameCount = fps * duration;
const width = 1080;
const height = 1920;
const snapshotsOnly = process.argv.includes('--snapshots-only');
const controlsOnly = process.argv.includes('--check-controls');
const requested = process.argv.slice(2).filter(value => !['--snapshots-only', '--check-controls'].includes(value));
const themes = requested.length ? requested : ['claro', 'escuro'];
if (themes.some(theme => !['claro', 'escuro'].includes(theme))) throw new Error('Use claro e/ou escuro como argumentos.');
await mkdir(exportsRoot, { recursive: true });
const mime = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.ttf': 'font/ttf', '.jpeg': 'image/jpeg', '.png': 'image/png', '.mp4': 'video/mp4' };
const server = createServer(async (req, res) => {
  try {
    const pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
    const target = path.resolve(root, '.' + (pathname.endsWith('/') ? pathname + 'index.html' : pathname));
    if (!target.startsWith(root + path.sep)) throw new Error('Forbidden');
    const content = await readFile(target);
    res.writeHead(200, { 'Content-Type': mime[path.extname(target)] || 'application/octet-stream' });
    res.end(content);
  } catch {
    res.writeHead(404);
    res.end('Not found');
  }
});

function encode(output) {
  const process = spawn('ffmpeg', [
    '-hide_banner', '-loglevel', 'warning', '-y',
    '-f', 'image2pipe', '-framerate', String(fps), '-vcodec', 'mjpeg', '-i', 'pipe:0',
    '-an', '-vf', 'scale=in_range=pc:out_range=tv:out_color_matrix=bt709,format=yuv420p',
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18',
    '-pix_fmt', 'yuv420p', '-color_range', 'tv', '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709',
    '-threads', '2', '-frames:v', String(frameCount),
    '-movflags', '+faststart', '-metadata', 'title=Jarilo — Teaser V3', output
  ], { stdio: ['pipe', 'ignore', 'pipe'] });
  let log = '';
  process.stderr.on('data', data => { log = (log + data.toString()).slice(-20000); });
  // The write callback reports a closed encoder without an unhandled EPIPE event.
  process.stdin.on('error', () => {});
  const completed = new Promise((resolve, reject) => {
    process.once('error', reject);
    process.once('close', code => code === 0 ? resolve(log) : reject(new Error(`ffmpeg terminou com ${code}: ${log}`)));
  });
  completed.catch(() => {});
  return { process, completed, get log() { return log; } };
}

let browser;
const manifest = { version: 3, duration, fps, width, height, audio: false, timeline: [
  { id: 'intro', from: 0, to: 2, scene: null },
  { id: 'reveal', from: 2, to: 5.6, scene: null },
  { id: 'outro', from: 5.6, to: 8, scene: null }
], exports: [] };

try {
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const base = 'http://127.0.0.1:' + server.address().port;
  browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  if (controlsOnly) {
    const page = await browser.newPage({ viewport: { width: 1100, height: 1400 }, reducedMotion: 'no-preference' });
    await page.goto(`${base}/estudo-03/reels-claro.html`);
    await page.waitForFunction(() => !!window.jariloMotion);
    await page.locator('[data-action="play"]').click();
    const paused = await page.evaluate(() => ({ time: jariloMotion.currentTime, running: jariloMotion.running }));
    await page.waitForTimeout(220);
    const still = await page.evaluate(() => jariloMotion.currentTime);
    if (paused.running || Math.abs(still - paused.time) > .02) throw new Error('O botão Pausar não suspendeu a animação.');
    await page.locator('[data-action="play"]').click();
    await page.waitForTimeout(220);
    const played = await page.evaluate(() => ({ time: jariloMotion.currentTime, running: jariloMotion.running }));
    if (!played.running || played.time <= still + .1) throw new Error('O botão Reproduzir não retomou a animação.');
    await page.locator('input[data-action="seek"]').evaluate(input => { input.value = '3.8'; input.dispatchEvent(new Event('input', { bubbles: true })); });
    const scrubbed = await page.evaluate(() => ({ time: jariloMotion.currentTime, running: jariloMotion.running, scene: getComputedStyle(document.querySelector('[data-scene="reveal"]')).opacity }));
    if (Math.abs(scrubbed.time - 3.8) > .01 || scrubbed.running || scrubbed.scene !== '1') throw new Error('O controle de tempo não posicionou a cena corretamente.');
    const deterministic = await page.evaluate(() => {
      jariloMotion.seek(1.123);
      const first = [...document.querySelectorAll('.wave-bar')].map(bar => bar.getAttribute('height')).join(',');
      jariloMotion.seek(4.56);
      jariloMotion.seek(1.123);
      const repeated = [...document.querySelectorAll('.wave-bar')].map(bar => bar.getAttribute('height')).join(',');
      jariloMotion.seek(0);
      const initial = Number(getComputedStyle(document.querySelector('[data-scene="intro"]')).opacity);
      jariloMotion.seek(8);
      const final = Number(getComputedStyle(document.querySelector('[data-scene="outro"]')).opacity);
      return first === repeated && initial === 1 && final === 1;
    });
    if (!deterministic) throw new Error('Seek não determinístico ou quadro vazio no início/fim.');
    await page.locator('[data-action="restart"]').click();
    const restarted = await page.evaluate(() => ({ time: jariloMotion.currentTime, running: jariloMotion.running }));
    if (!restarted.running || restarted.time > .3) throw new Error('O botão Reiniciar falhou.');
    await page.close();
    const reduced = await browser.newPage({ viewport: { width: 1100, height: 1400 }, reducedMotion: 'reduce' });
    await reduced.goto(`${base}/estudo-03/reels-escuro.html`);
    await reduced.waitForFunction(() => !!window.jariloMotion);
    const reducedState = await reduced.evaluate(() => ({ time: jariloMotion.currentTime, running: jariloMotion.running }));
    if (reducedState.running || reducedState.time !== 3.8) throw new Error('Preferência de movimento reduzido não foi respeitada.');
    await reduced.close();
    console.log('Controles verificados: pausa, reprodução, seek, reinício, determinismo, quadros inicial/final e movimento reduzido.');
  }
  for (const theme of (controlsOnly ? [] : themes)) {
    const page = await browser.newPage({ viewport: { width, height }, deviceScaleFactor: 1, reducedMotion: 'no-preference' });
    const failures = [];
    page.on('pageerror', error => failures.push(error.message));
    await page.goto(`${base}/estudo-03/reels-${theme}.html?export=1`, { waitUntil: 'load' });
    await page.evaluate(() => document.fonts.ready);
    await page.waitForFunction(() => !!window.jariloMotion);
    await page.addStyleTag({ content: `
      html,body{margin:0!important;padding:0!important;overflow:hidden!important}
      .motion-controls{display:none!important}
      .art{transform:none!important;margin:0!important;width:${width}px!important;height:${height}px!important}
      .viewport{width:${width}px!important;height:${height}px!important}
    ` });
    const details = await page.evaluate(() => ({
      fonts: document.fonts.check('800 100px "Barlow Condensed"'),
      images: [...document.images].every(image => image.complete && image.naturalWidth > 0),
      scenes: document.querySelectorAll('.motion-scene').length,
      sceneTexts: Object.fromEntries([...document.querySelectorAll('.motion-scene[data-scene]')].map(scene => [scene.dataset.scene,
        [...scene.querySelectorAll('h1,p')].map(block => [...block.childNodes].map(node => node.textContent.trim()).filter(Boolean).join(' ')).join(' ').replace(/\s+/g, ' ').trim()
      ])),
      bars: document.querySelectorAll('.wave-bar').length,
      duration: window.jariloMotion.duration,
      paused: !window.jariloMotion.running
    }));
    if (!details.fonts || !details.images || details.scenes !== 3 || details.bars === 0 || details.duration !== duration || !details.paused) {
      throw new Error(`HTML incompleto (${theme}): ${JSON.stringify(details)}`);
    }
    // Derive captions from the actual HTML so revised teaser copy cannot leave
    // a previous, more explicit message behind in the exported manifest.
    for (const entry of manifest.timeline) entry.scene = details.sceneTexts[entry.id];
    const box = await page.locator('.art').boundingBox();
    if (!box || Math.abs(box.width - width) > .1 || Math.abs(box.height - height) > .1) throw new Error('Dimensões da arte incorretas: ' + JSON.stringify(box));
    const clip = { x: box.x, y: box.y, width, height };
    for (const [index, time] of [1, 3.8, 6.8].entries()) {
      await page.evaluate(t => window.jariloMotion.seek(t), time);
      await page.screenshot({ path: path.join(exportsRoot, `reels-${theme}-cena-${index + 1}.png`), clip, animations: 'allow' });
    }
    if (snapshotsOnly) {
      console.log(`${theme}: três cenas PNG prontas para revisão`);
      await page.close();
      continue;
    }
    const output = path.join(exportsRoot, `reels-${theme}.mp4`);
    const encoder = encode(output);
    try {
      for (let index = 0; index < frameCount; index++) {
        await page.evaluate(time => window.jariloMotion.seek(time), index / fps);
        const buffer = await page.screenshot({ type: 'jpeg', quality: 94, clip, animations: 'allow' });
        await new Promise((resolve, reject) => encoder.process.stdin.write(buffer, error => error ? reject(error) : resolve()));
        if (index % 30 === 0) console.log(`${theme}: ${index}/${frameCount} quadros`);
      }
      encoder.process.stdin.end();
      await encoder.completed;
    } catch (error) {
      encoder.process.stdin.destroy();
      encoder.process.kill('SIGTERM');
      await encoder.completed.catch(() => {});
      throw error;
    }
    if (failures.length) throw new Error(`Erros JavaScript: ${failures.join('; ')}`);
    const probe = JSON.parse(execFileSync('ffprobe', ['-v', 'error', '-show_format', '-show_streams', '-of', 'json', output], { encoding: 'utf8' }));
    const video = probe.streams.find(stream => stream.codec_type === 'video');
    const actualFrames = Number(video?.nb_frames);
    if (!video || video.codec_name !== 'h264' || video.pix_fmt !== 'yuv420p' || video.width !== width || video.height !== height || video.r_frame_rate !== '30/1' || Math.abs(Number(probe.format.duration) - duration) > .05 || (Number.isFinite(actualFrames) && actualFrames !== frameCount) || probe.streams.some(stream => stream.codec_type === 'audio')) {
      throw new Error('Verificação do vídeo falhou: ' + JSON.stringify(probe));
    }
    manifest.exports.push({ theme, filename: path.basename(output), frames: frameCount, codec: video.codec_name, pixelFormat: video.pix_fmt, duration: Number(probe.format.duration), size: Number(probe.format.size) });
    await writeFile(path.join(exportsRoot, `reels-${theme}-encode.log`), encoder.log);
    console.log(`${theme}: MP4 verificado, ${width}×${height}, ${fps} fps, ${duration} s, ${frameCount} quadros, sem áudio`);
    await page.close();
  }
  if (!snapshotsOnly && !controlsOnly) await writeFile(path.join(exportsRoot, 'motion-manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
} finally {
  if (browser) await browser.close();
  if (server.listening) await new Promise(resolve => server.close(resolve));
}
