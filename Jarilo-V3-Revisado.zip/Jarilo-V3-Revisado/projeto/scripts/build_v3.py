"""Build all V3 artboards from shared content, without touching V1 or V2."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent / 'estudo-03'
root.mkdir(exist_ok=True)
(root / 'exports').mkdir(exist_ok=True)

def terrain():
    paths=[]
    for i in range(17):
        x=290+i*52; y=210+i*36
        paths.append(f'<path d="M1160 {y} C{x} {y-170} {x-390} {y+60} {x-180} {y+320} S{x+20} {y+740} -180 {y+870}"/>')
    return '<svg class="land" viewBox="0 0 1080 990" aria-hidden="true">'+''.join(paths)+'</svg>'

def signal(motion=False):
    heights=[7,11,18,12,24,39,22,48,64,32,57,84,49,76,103,64,90,126,85,110,145,102,126,95,138,114,79,108,68,89,60,76,46,62,35,48,27,38,19,28,16,21,12,16,8,12,6,8]
    bars=''.join(f'<rect class="wave-bar" data-base-height="{h}" x="{9+i*16}" y="{90-h/2}" width="6" height="{h}" rx="3"/>' for i,h in enumerate(heights))
    return '<div class="voice-capsule '+('motion-capsule' if motion else '')+'" aria-hidden="true"><svg class="sound" viewBox="0 0 780 180">'+bars+'</svg></div>'

brand='''<header class="topline"><div class="brand" role="img" aria-label="Jarilo"><img src="../assets/jarilo-capa-original.jpeg" alt="" width="3840" height="2160"></div><div class="soon">Em breve</div></header>'''
footer='''<footer class="bottomline"><span>Fique de olho.</span><span>Jarilo</span></footer>'''
headline='''<h1 class="headline"><span class="line">Prepare-se.</span><span class="line">Um novo</span><span class="voice">Jarilo</span></h1>'''
poll='''<div class="poll" role="img" aria-label="Referência visual da enquete: Tenho um palpite ou Me surpreenda. Inserir enquete nativa na publicação."><span class="poll-option">Tenho um palpite</span><span class="poll-option">Me surpreenda</span></div>'''

controls='''<section class="controls" aria-label="Controles de prévia do motion"><button type="button" data-action="play">Pausar</button><button type="button" data-action="restart">Reiniciar</button><label for="motion-seek">Tempo</label><input id="motion-seek" data-action="seek" type="range" min="0" max="8" step="0.01" value="0" aria-label="Posição da animação em segundos"><span data-time>0,0 / 8 s</span><p>Prévia visual de 8 segundos, sem trilha sonora.</p></section>'''

for theme in ['claro','escuro']:
    for fmt in ['feed','story','reels']:
        height=1350 if fmt=='feed' else 1920
        if fmt=='feed':
            content='<p class="eyebrow feed-eyebrow">Tem novidade no campo.</p>'+headline+signal()+'<p class="support">vai te encontrar.</p>'
        elif fmt=='story':
            content='''<h1 class="question"><span class="question-intro">O que você</span><span class="type-word">acha que</span><span class="speak-word">vem aí<span class="question-mark">?</span></span></h1>'''+signal()+poll+'<p class="support">Tem novidade chegando<br><strong>no Jarilo.</strong></p>'
        else:
            content='''<section class="motion-scene" data-scene="intro" aria-label="Cena 1"><h1 class="intro-title"><span>O campo tem</span><span>muito</span><span class="accent">a dizer.</span></h1><p class="intro-note">Uma novidade está chegando.</p></section>
<section class="motion-scene" data-scene="reveal" aria-label="Cena 2">'''+headline+'''<p class="support">vai te encontrar.</p></section>
<section class="motion-scene" data-scene="outro" aria-label="Cena 3"><h1 class="outro-title"><span>Prepare-se.</span><span class="outro-emphasis">Em breve.</span></h1><p class="outro-note">O que será que vem aí?</p></section>'''+signal(True)
        label='O que você acha que vem aí?' if fmt=='story' else 'Prepare-se. Um novo Jarilo vai te encontrar. Em breve.'
        doc=f'''<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Jarilo V3 · {fmt.title()} · {theme.title()}</title><link rel="stylesheet" href="art.css"><style>@media print{{@page{{size:1080px {height}px;margin:0}}}}</style></head>
<body class="{fmt} {theme}"><main class="viewport"><article class="art" aria-label="{label}">{brand}{terrain()}{content}{footer}</article></main>{controls if fmt=='reels' else ''}
<script>
const query=new URLSearchParams(location.search);if(query.has('export'))document.body.classList.add('export-mode');if(query.has('embed'))document.body.classList.add('embedded');if(query.has('base'))document.body.classList.add('poll-base');
function fit(){{const bare=query.has('export')||query.has('embed');const width=Math.min(bare?1080:540,document.documentElement.clientWidth-(bare?0:32));const viewport=document.querySelector('.viewport');viewport.style.width=width+'px';viewport.style.height=({height}*width/1080)+'px';document.querySelector('.art').style.transform='scale('+width/1080+')';}}fit();addEventListener('resize',fit);
</script>{'<script src="motion.js"></script>' if fmt=='reels' else ''}</body></html>'''
        (root/f'{fmt}-{theme}.html').write_text(doc,encoding='utf-8')
print('V3: seis HTMLs gerados, com temas claro e escuro.')
