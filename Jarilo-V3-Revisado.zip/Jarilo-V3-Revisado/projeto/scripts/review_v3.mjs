import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {createServer} from 'node:http';
import {readFile,writeFile,copyFile} from 'node:fs/promises';
import {once} from 'node:events';
import path from 'node:path';
const require=createRequire(import.meta.url);const {chromium}=require('playwright');
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.join(root,'estudo-03','exports');
const mime={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.ttf':'font/ttf','.jpeg':'image/jpeg','.png':'image/png','.pdf':'application/pdf','.mp4':'video/mp4'};
const server=createServer(async(req,res)=>{
 try{
  const p=decodeURIComponent(new URL(req.url,'http://local').pathname);
  const f=path.resolve(root,'.'+(p.endsWith('/')?p+'index.html':p));
  if(!f.startsWith(root+path.sep))throw Error();
  const data=await readFile(f);
  const headers={'Content-Type':mime[path.extname(f)]||'application/octet-stream','Accept-Ranges':'bytes','Content-Security-Policy':"frame-src 'none'; object-src 'none'"};
  const range=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range||'');
  if(range){
   const start=range[1]?Number(range[1]):Math.max(0,data.length-Number(range[2]));
   const end=Math.min(range[1]&&range[2]?Number(range[2]):data.length-1,data.length-1);
   if(start>=data.length||end<start){res.writeHead(416,{'Content-Range':`bytes */${data.length}`});res.end();return;}
   res.writeHead(206,{...headers,'Content-Range':`bytes ${start}-${end}/${data.length}`,'Content-Length':end-start+1});res.end(data.subarray(start,end+1));
  }else{res.writeHead(200,{...headers,'Content-Length':data.length});res.end(data);}
 }catch{res.writeHead(404);res.end();}
});
let browser;const report=[];
try{
 server.listen(0,'127.0.0.1');await once(server,'listening');
 const base=`http://127.0.0.1:${server.address().port}/estudo-03`;
 browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
 for(const width of [1440,390]){
  const page=await browser.newPage({viewport:{width,height:1080},deviceScaleFactor:1,reducedMotion:'reduce'});const errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(base+'/index.html');await page.evaluate(()=>document.fonts.ready);
  await page.waitForFunction(()=>[...document.querySelectorAll('.art-frame>img')].every(i=>i.complete&&i.naturalWidth>0));
  await page.waitForFunction(()=>[...document.querySelectorAll('video')].every(v=>v.readyState>=2));
  await page.evaluate(async()=>{for(const v of document.querySelectorAll('video')){v.pause();await new Promise(resolve=>{v.addEventListener('seeked',resolve,{once:true});v.currentTime=3.8;});}});
  const info=await page.evaluate(()=>({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,frames:document.querySelectorAll('iframe').length,images:[...document.querySelectorAll('.art-frame>img')].map(i=>({loaded:i.complete&&i.naturalWidth>0,width:i.naturalWidth,height:i.naturalHeight})),videos:[...document.querySelectorAll('video')].map(v=>({duration:v.duration,currentTime:v.currentTime,width:v.videoWidth,height:v.videoHeight,paused:v.paused,error:v.error?.message||null}))}));
  if(info.scrollWidth>width||info.frames!==0||info.images.length!==4||info.images.some(i=>!i.loaded||i.width!==1080)||info.videos.length!==2||info.videos.some(v=>v.duration!==8||Math.abs(v.currentTime-3.8)>.05||v.width!==1080||v.height!==1920||v.error)||errors.length)throw Error(JSON.stringify({info,errors}));
  // The overview is a static artifact: use the exported main-frame posters,
  // rather than capture transient native loading overlays or media controls.
  await page.evaluate(()=>{for(const video of document.querySelectorAll('video')){const image=document.createElement('img');image.src=video.poster;image.alt=video.getAttribute('aria-label');image.style.cssText='display:block;width:100%;height:100%;object-fit:contain';video.replaceWith(image);}});
  await page.waitForFunction(()=>[...document.images].every(i=>i.complete&&i.naturalWidth>0));
  await page.screenshot({path:path.join(out,width===1440?'jarilo-v3-visao-geral.png':'jarilo-v3-mobile.png'),fullPage:true});
  if(width===1440)await copyFile(path.join(out,'jarilo-v3-visao-geral.png'),path.join(out,'jarilo-v3-teaser-visao-geral.png'));
  report.push({info,errors});await page.close();
 }
 const portable=await browser.newPage({viewport:{width:1100,height:900},reducedMotion:'reduce'});
 const portableURL=base+'/Jarilo-V3-teaser.html';
 const external=[];
 await portable.route('**/*',route=>{if(route.request().url()===portableURL)return route.continue();external.push(route.request().url());return route.abort();});
 await portable.goto(portableURL);await portable.evaluate(()=>document.fonts.ready);
 await portable.waitForFunction(()=>[...document.querySelectorAll('.art-frame>img')].every(i=>i.complete&&i.naturalWidth>0)&&[...document.querySelectorAll('video')].every(v=>v.readyState>=2));
 const embedded=await portable.evaluate(()=>({frames:document.querySelectorAll('iframe').length,images:document.querySelectorAll('.art-frame>img[src^="data:"]').length,videos:[...document.querySelectorAll('video')].map(v=>({duration:v.duration,width:v.videoWidth,height:v.videoHeight})),fonts:document.fonts.check('800 100px "Barlow Condensed"')}));
 if(external.length||embedded.frames!==0||embedded.images!==4||embedded.videos.length!==2||embedded.videos.some(v=>v.duration!==8||v.width!==1080||v.height!==1920)||!embedded.fonts)throw Error(JSON.stringify({external,embedded}));
 report.push({portable:embedded,externalRequests:external.length});await portable.close();
 await writeFile(path.join(out,'gallery-validation.json'),JSON.stringify(report,null,2));
 console.log("Galeria verificada em 1440/390 px com frame-src 'none': quatro imagens carregadas, zero iframes e dois vídeos 1080×1920/8 s, sem erros ou overflow.");
 console.log('Apresentação em arquivo único verificada sem requisições de assets externos.');
}finally{if(browser)await browser.close();if(server.listening)await new Promise(resolve=>server.close(resolve));}
