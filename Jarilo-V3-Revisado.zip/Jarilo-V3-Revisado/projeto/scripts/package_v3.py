"""Package the reviewed delivery and audit every extracted HTML/CSS dependency."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from shutil import copyfile
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
from hashlib import sha256
import tempfile
import re

root = Path(__file__).resolve().parent.parent
v3 = root / 'estudo-03'
output = root / 'entrega'
output.mkdir(exist_ok=True)
target = output / 'Jarilo-V3-Revisado.zip'
folder = 'Jarilo-V3-Revisado'
files = {}

def add_file(source, destination):
    assert source.is_file(), source
    files[destination] = source.read_bytes()

def add_text(destination, text):
    files[destination] = text.encode('utf-8')

add_file(v3 / 'Jarilo-V3-teaser.html', 'index.html')
add_text('LEIA-ME.md', '''# Jarilo — Teaser V3 revisado

1. Extraia esta pasta ZIP por completo.
2. Abra **index.html** no navegador. Essa apresentação inclui as fontes,
   imagens, vídeos e PDF no próprio arquivo, sem páginas incorporadas.
3. Os arquivos separados estão em **projeto/estudo-03/exports**.
4. Para editar, use os HTMLs, CSS e JavaScript de **projeto/estudo-03**.
   Preserve a estrutura de pastas e os assets em **projeto/assets**.

## O que está incluído

- Feed, Story e Reels em versões clara e escura.
- PNGs, PDFs, MP4s de 8 segundos e storyboard.
- Base do Story para aplicar a enquete nativa na publicação.
- Fontes HTML/CSS/JS, assets, licenças e scripts de exportação.
- Briefing, legendas sugeridas e instruções de edição.
- Relatório de revisão e hashes de integridade.

A comunicação preserva a surpresa: “Prepare-se. Um novo Jarilo vai te encontrar.”
O Story pergunta “O que você acha que vem aí?”, com “Tenho um palpite” e
“Me surpreenda”. Os vídeos estão sem trilha sonora. Nada foi publicado.

Esta entrega contém a versão final revisada. Os estudos anteriores e arquivos
redundantes não estão misturados aos materiais finais.
''')
for source in sorted((root / 'assets').iterdir()):
    if source.is_file():
        add_file(source, 'projeto/assets/' + source.name)
for source in sorted(v3.iterdir()):
    if source.is_file() and source.name != 'Jarilo-V3-teaser.html':
        add_file(source, 'projeto/estudo-03/' + source.name)
for theme in ['claro', 'escuro']:
    names = [f'feed-{theme}.png', f'feed-{theme}.pdf',
             f'story-{theme}.png', f'story-{theme}.pdf', f'story-{theme}-base.png',
             f'reels-{theme}.mp4']
    names += [f'reels-{theme}-cena-{scene}.{ext}' for scene in [1, 2, 3] for ext in ['png', 'pdf']]
    for name in names:
        add_file(v3 / 'exports' / name, 'projeto/estudo-03/exports/' + name)
for name in ['jarilo-v3-teaser.pdf', 'jarilo-v3-teaser-visao-geral.png', 'jarilo-v3-mobile.png']:
    add_file(v3 / 'exports' / name, 'projeto/estudo-03/exports/' + name)
for name in ['build_v3.py', 'export_static_v3.mjs', 'export_motion_v3.mjs',
             'finalize_v3.py', 'review_v3.mjs', 'build_portable_v3.py', 'package_v3.py']:
    add_file(root / 'scripts' / name, 'projeto/scripts/' + name)

class Document(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs = []
        self.ids = set()
        self.tags = []
        self.text = []
        self.skip = 0
        self.bad_download = False
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.tags.append(tag)
        if tag in ['script', 'style']:
            self.skip += 1
        if attrs.get('id'):
            assert attrs['id'] not in self.ids, 'Duplicate element ID'
            self.ids.add(attrs['id'])
        for key in ['src', 'href', 'poster']:
            value = attrs.get(key, '')
            if value:
                self.refs.append(value)
        for key in ['alt', 'title', 'aria-label']:
            self.text.append(attrs.get(key, ''))
        if tag == 'a' and attrs.get('href', '').startswith('data:'):
            if not attrs.get('download'):
                self.bad_download = True
    def handle_endtag(self, tag):
        if tag in ['script', 'style']:
            self.skip -= 1
    def handle_data(self, value):
        if self.skip == 0:
            self.text.append(value)

def audit(directory):
    html_count = 0
    ref_count = 0
    for file in sorted(directory.rglob('*.html')):
        html_count += 1
        doc = Document()
        doc.feed(file.read_text())
        assert not any(tag in doc.tags for tag in ['iframe', 'object', 'embed']), file
        assert not doc.bad_download, f'Embedded download lacks filename: {file}'
        visible = ' '.join(doc.text).lower()
        for forbidden in ['vai ganhar voz', 'por voz', 'digitar ou falar', 'conversar por voz', 'voz oficial']:
            assert forbidden not in visible, (file, forbidden)
        for ref in doc.refs:
            if ref.startswith(('data:', 'https:', 'http:', 'mailto:')):
                continue
            parsed = urlsplit(ref)
            if parsed.path:
                referenced = (file.parent / unquote(parsed.path)).resolve()
                assert referenced.is_relative_to(directory.resolve()), (file, 'Reference escapes package')
                assert referenced.is_file(), (file.relative_to(directory), ref)
                ref_count += 1
            elif parsed.fragment:
                assert parsed.fragment in doc.ids, (file, ref)
    for file in sorted(directory.rglob('*.css')):
        for value in re.findall(r'url\([\x27\"]?([^\x27\")]+)', file.read_text()):
            if not value.startswith(('data:', 'https:', 'http:')):
                assert (file.parent / unquote(value)).is_file(), (file, value)
    assert html_count == 8, html_count
    return html_count, ref_count

with tempfile.TemporaryDirectory(prefix='jarilo-final-audit-', dir='/tmp') as tmp:
    stage = Path(tmp)
    for name, data in files.items():
        file = stage / name
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_bytes(data)
    html_count, ref_count = audit(stage)

add_text('REVISAO.md', f'''# Revisão da entrega

- {html_count} HTMLs revisados: uma apresentação em arquivo único, uma galeria editável e seis peças.
- {ref_count} referências locais verificadas, além dos assets embutidos e fontes CSS.
- Nenhum iframe, objeto incorporado ou download com nome indefinido.
- Galeria conferida no Chromium em 1440 e 390 px, com `frame-src 'none'`.
- Apresentação em arquivo único conferida com assets externos bloqueados.
- PDFs íntegros e com conteúdo de expectativa; storyboard de dez páginas.
- PNGs nas dimensões corretas; Story inclui bases sem enquete desenhada.
- Dois MP4s: 1080 × 1920, 30 fps, 8 segundos, 240 quadros, H.264/yuv420p, sem áudio.
- Vídeos decodificados integralmente sem erro.
- Links relativos e nomes de download conferidos após extração do pacote.
- Versões anteriores, ZIPs dentro do ZIP, aliases, logs e relatórios temporários excluídos.

Essas verificações são locais. A execução dentro de um visualizador de terceiros
pode seguir políticas próprias; a apresentação dispensa páginas incorporadas.
''')
add_text('SHA256.txt', ''.join(f'{sha256(data).hexdigest()}  {name}\n' for name, data in sorted(files.items())))
with ZipFile(target, 'w', ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(files.items()):
        z.writestr(folder + '/' + name, data)
with ZipFile(target) as z:
    assert z.testzip() is None
    assert not any(name.endswith('.zip') for name in z.namelist())
    with tempfile.TemporaryDirectory(prefix='jarilo-zip-verify-', dir='/tmp') as tmp:
        z.extractall(tmp)
        extracted = Path(tmp) / folder
        for name, data in files.items():
            assert sha256((extracted / name).read_bytes()).digest() == sha256(data).digest(), name
        audit(extracted)
for alias in ['jarilo-v3-teaser.zip', 'jarilo-v3-pacote.zip']:
    copyfile(target, v3 / 'exports' / alias)
print(f'Entrega final: {target}')
print(f'{len(files)} arquivos, {html_count} HTMLs; extração, links e SHA-256 verificados.')
print(f'Tamanho: {target.stat().st_size / 1024 / 1024:.1f} MB')
