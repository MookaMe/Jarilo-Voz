import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {createServer} from 'node:http';
import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {once} from 'node:events';
import path from 'node:path';
const require=createRequire(import.meta.url);
const {chromium}=require('playwright');
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.join(root,'estudo-03','exports');
await mkdir(out,{recursive:true});
const mime={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.ttf':'font/ttf','.jpeg':'image/jpeg','.png':'image/png','.pdf':'application/pdf','.mp4':'video/mp4'};
const server=createServer(async(req,res)=>{try{const p=decodeURIComponent(new URL(req.url,'http://local').pathname);const file=path.resolve(root,'.'+(p.endsWith('/')?p+'index.html':p));if(!file.startsWith(root+path.sep))throw Error('Forbidden');const data=await readFile(file);res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream'});res.end(data);}catch{res.writeHead(404);res.end();}});
let browser;
const results=[];
try{
  server.listen(0,'127.0.0.1');await once(server,'listening');
  const base=`http://127.0.0.1:${server.address().port}/estudo-03`;
  browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage']});
  for(const theme of ['claro','escuro']){
    for(const format of ['feed','story','reels']){
      const height=format==='feed'?1350:1920;
      const page=await browser.newPage({viewport:{width:1080,height},deviceScaleFactor:1});
      const errors=[];page.on('pageerror',e=>errors.push(e.message));
      await page.goto(`${base}/${format}-${theme}.html?export=1`);
      await page.evaluate(()=>document.fonts.ready);
      const details=await page.evaluate(()=>({fonts:document.fonts.check('800 100px "Barlow Condensed"'),images:[...document.images].every(i=>i.complete&&i.naturalWidth>0),width:document.querySelector('.art').offsetWidth,height:document.querySelector('.art').offsetHeight}));
      if(errors.length||!details.fonts||!details.images||details.width!==1080||details.height!==height)throw Error(JSON.stringify({errors,details}));
      const pdfOptions={width:'1080px',height:`${height}px`,preferCSSPageSize:true,printBackground:true,margin:{top:0,right:0,bottom:0,left:0}};
      if(format==='reels'){
        await page.waitForFunction(()=>!!window.jariloMotion);
        for(const [index,t]of [1,3.8,6.8].entries()){
          await page.evaluate(t=>window.jariloMotion.seek(t),t);
          await page.pdf({...pdfOptions,path:path.join(out,`reels-${theme}-cena-${index+1}.pdf`)});
        }
      }else{
        await page.locator('.art').screenshot({path:path.join(out,`${format}-${theme}.png`)});
        await page.pdf({...pdfOptions,path:path.join(out,`${format}-${theme}.pdf`)});
        if(format==='story'){
          await page.evaluate(()=>document.body.classList.add('poll-base'));
          await page.locator('.art').screenshot({path:path.join(out,`story-${theme}-base.png`)});
        }
      }
      results.push({theme,format,...details,errors});console.log(`${theme}/${format}: dimensões, fontes e imagens verificadas`);
      await page.close();
    }
  }
  await writeFile(path.join(out,'static-validation.json'),JSON.stringify(results,null,2));
}finally{if(browser)await browser.close();if(server.listening)await new Promise(resolve=>server.close(resolve));}
