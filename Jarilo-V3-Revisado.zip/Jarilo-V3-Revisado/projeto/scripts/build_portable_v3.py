"""Build a single-file presentation without iframes or external display assets."""
from pathlib import Path
from base64 import b64encode
import mimetypes
import re

root=Path(__file__).resolve().parent.parent/'estudo-03'
cache={}
def data_url(file):
    file=file.resolve()
    if file not in cache:
        mime=mimetypes.guess_type(file.name)[0] or 'application/octet-stream'
        cache[file]=f'data:{mime};base64,'+b64encode(file.read_bytes()).decode('ascii')
    return cache[file]

html=(root/'index.html').read_text()
assert '<iframe' not in html
css=(root/'gallery.css').read_text()
for name in ['Barlow-Regular.ttf','Barlow-SemiBold.ttf','BarlowCondensed-ExtraBold.ttf']:
    css=css.replace('../assets/'+name,data_url(root.parent/'assets'/name))
html=html.replace('<link rel="stylesheet" href="gallery.css">','<style>'+css+'</style>')
html=html.replace('<script src="gallery.js" defer></script>','<script>'+ (root/'gallery.js').read_text()+'</script>')
# The script originally used defer; keep its execution after the DOM is ready.
script=re.search(r'<script>(.*?)</script>',html,re.S)
if script:
    html=html[:script.start()]+html[script.end():]
    html=html.replace('</body>','<script>'+script.group(1)+'</script></body>')
html=re.sub(r'\b(src|poster)="(exports/[^\"]+)"',lambda m:f'{m[1]}="{data_url(root/m[2])}"',html)

def link(match):
    href=match[1]
    block=match[0]
    if href.endswith(('.html','.zip')):
        return ''
    if not href.startswith('#'):
        file=root/href
        if file.is_file():
            block=block.replace(f'href="{href}"',f'href="{data_url(file)}"')
            # Data URLs cannot supply a useful filename on their own.
            # Give every embedded download its original filename explicitly.
            block=re.sub(r'\sdownload(?:\s*=\s*(?:"[^"]*"|\x27[^\x27]*\x27|[^\s>]+))?(?=\s|>)','',block,count=1)
            block=block.replace('<a ',f'<a download="{file.name}" ',1)
    return block

html=re.sub(r'<a\b[^>]*href="([^\"]+)"[^>]*>.*?</a>',link,html,flags=re.S)
html=html.replace('<title>Jarilo · V3 · Clara e escura</title>',
                  '<title>Jarilo · Teaser V3 · Apresentação corrigida</title>')
target=root/'Jarilo-V3-teaser.html'
target.write_text(html)
(root/'Jarilo-V3-apresentacao.html').unlink(missing_ok=True)
assert '<iframe' not in html
assert not re.search(r'\b(?:src|poster)="(?!data:)[^\"]+"',html)
print(f'Apresentação única criada: {target.name}, {target.stat().st_size/1024/1024:.1f} MB')
