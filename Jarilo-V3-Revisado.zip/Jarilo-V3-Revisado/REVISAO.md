# Revisão da entrega

- 8 HTMLs revisados: uma apresentação em arquivo único, uma galeria editável e seis peças.
- 42 referências locais verificadas, além dos assets embutidos e fontes CSS.
- Nenhum iframe, objeto incorporado ou download com nome indefinido.
- Galeria conferida no Chromium em 1440 e 390 px, com `frame-src 'none'`.
- Apresentação em arquivo único conferida com assets externos bloqueados.
- PDFs íntegros e com conteúdo de expectativa; storyboard de dez páginas.
- PNGs nas dimensões corretas; Story inclui bases sem enquete desenhada.
- Dois MP4s: 1080 × 1920, 30 fps, 8 segundos, 240 quadros, H.264/yuv420p, sem áudio.
- Vídeos decodificados integralmente sem erro.
- Links relativos e nomes de download conferidos após extração do pacote.
- Versões anteriores, ZIPs dentro do ZIP, aliases, logs e relatórios temporários excluídos.

Essas verificações são locais. A execução dentro de um visualizador de terceiros
pode seguir políticas próprias; a apresentação dispensa páginas incorporadas.
