# Jarilo — Teaser V3 revisado

1. Extraia esta pasta ZIP por completo.
2. Abra **index.html** no navegador. Essa apresentação inclui as fontes,
   imagens, vídeos e PDF no próprio arquivo, sem páginas incorporadas.
3. Os arquivos separados estão em **projeto/estudo-03/exports**.
4. Para editar, use os HTMLs, CSS e JavaScript de **projeto/estudo-03**.
   Preserve a estrutura de pastas e os assets em **projeto/assets**.

## O que está incluído

- Feed, Story e Reels em versões clara e escura.
- PNGs, PDFs, MP4s de 8 segundos e storyboard.
- Base do Story para aplicar a enquete nativa na publicação.
- Fontes HTML/CSS/JS, assets, licenças e scripts de exportação.
- Briefing, legendas sugeridas e instruções de edição.
- Relatório de revisão e hashes de integridade.

A comunicação preserva a surpresa: “Prepare-se. Um novo Jarilo vai te encontrar.”
O Story pergunta “O que você acha que vem aí?”, com “Tenho um palpite” e
“Me surpreenda”. Os vídeos estão sem trilha sonora. Nada foi publicado.

Esta entrega contém a versão final revisada. Os estudos anteriores e arquivos
redundantes não estão misturados aos materiais finais.
